CREATE DATABASE Nextlabs;

USE Nextlabs;

# How many incidents have incident_id on a given day. How many percentage of incidents have a non-null id?
Select date(date_time) as Incident_Date,count(*) as Total_Numbers_Of_Incident, 
Sum(case when instance_id!=0 then 1 else 0 end) as Incident_With_ID,
Sum(case when instance_id!=0 then 1 else 0 end)/count(*)*100 as Percentage_Incident_With_Non_Null_Value
FROM problem2
Where instance_id IS NOT Null
Group by Incident_date;

# The time is in UTC, so convert that into IST. 
Select date_time as UTC,addtime(date_time,"5:30:00:00000") as IST,instance_id
From problem2;

# What time of the day does the incident_id percentage is lower? 
Select extract(hour from date_time) as UTC ,extract(hour from addtime(date_time,"5:30:00:00000") )as IST,
Sum(case when instance_id!=0 then 1 else 0 end)/count(*)*100 as Percentage_Incident_With_Non_Null_Value
from problem2
group by IST
order by Percentage_incident_with_non_null_value;